import pandas as pd
from ReadNets import graphAttribute
from decimal import Decimal
import networkx as nx
pd.set_option('display.precision', 200)

class GEN:
    def __init__(self, _NetPath, _IEDF, METRIC, READCOLUMN):
        self.metric = METRIC
        self.NetPath = _NetPath
        net = graphAttribute(self.NetPath)
        self.G = net.GraphUndirUnWeight()
        ClassName = _IEDF[READCOLUMN]
        metric_str = _IEDF[self.metric].astype(str)
        ImportanceRank = metric_str.apply(lambda x: Decimal(x))
        
        self.class_ClassRank = dict(zip(ClassName, ImportanceRank))
        print("class_ClassRank:", self.class_ClassRank)

    def Get_Neigbors(self, Graph, v_i, order=1):
        neibords_set = {}
        neibords = dict(nx.bfs_successors(Graph, source=v_i, depth_limit=order))
        nodes = [v_i]
        for order_num in range(1, order + 1):
            neibords_set.setdefault(order_num, [])
            for node in nodes:
                neibords_set[order_num].extend(neibords.get(node, []))
            nodes = neibords_set[order_num]
        neighbords_list = []
        for j in neibords_set.values():
            for innode in j:
                neighbords_list.append(innode)
        return neighbords_list

    def RecordAllPath(self):
        '''
        :return:
        '''
        AllPath = {}
        v_i_neigbhords = {}
        nodes = list(self.G.nodes())
        for v_i in nodes:
            v_i_neigbhords[v_i] = self.Get_Neigbors(Graph=self.G, v_i=v_i, order=3)

        # 遍历图中所有节点，记录最短路径
        for node in self.G.nodes():
            AllPath.setdefault(node, [])
            for source in v_i_neigbhords[node]:
                if nx.has_path(self.G, source=node, target=source):
                    path = nx.shortest_path(self.G, source=node, target=source)
                    if len(path) - 1 <= 3:
                        AllPath[node].append(path)
        return AllPath

    def path_length(self, path, weight):
        w = 0
        for ind, nd in enumerate(path[1:]):
            prev = path[ind]
            w += self.G[prev][nd][weight]
        return w

    def _Calculate_GEN(self):
        N = len(self.G.nodes())
        nodes = list(self.G.nodes())
        v_i_neigbhords = {}

        for v_i in nodes:
            v_i_neigbhords[v_i] = self.Get_Neigbors(Graph=self.G, v_i=v_i, order=3)

        AllPath = self.RecordAllPath()

        # 存储最终结果
        GPC_v_i_dict = {}
        for i in range(N):
            neibords_set = v_i_neigbhords[nodes[i]]
            tmp_node_i = nodes[i]

            # 节点 i 的重要性
            v_i_ClassRank = self.class_ClassRank[tmp_node_i]

            GPC_v_i = 0
            for innode in neibords_set:
                F_ij = 0

                # 计算最短路径长度 d_ij
                d_ij = nx.shortest_path_length(self.G, source=nodes[i], target=innode)
                if d_ij > 3:
                    continue

                al_kj_dij = len([path for path in AllPath[innode] if len(path) - 1 == d_ij])
                al_ij = len([path for path in AllPath[tmp_node_i] if len(path) - 1 == d_ij])

                r_ij_d = Decimal(al_ij) / (Decimal(al_kj_dij) + Decimal('0.01'))
                v_j_ClassRank = self.class_ClassRank[innode]
                F_ij += r_ij_d * ((v_i_ClassRank * v_j_ClassRank) / (Decimal(d_ij) ** 2))

                GPC_v_i += F_ij

            # 保存结果
            GPC_v_i_dict[nodes[i]] = GPC_v_i

        # 转换为 DataFrame
        result = pd.DataFrame({'ClassName': list(GPC_v_i_dict.keys()), 'IE_GEN-SORA': list(GPC_v_i_dict.values())})
        return result
