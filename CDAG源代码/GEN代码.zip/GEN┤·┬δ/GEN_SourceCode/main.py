import os

import pandas as pd
from GEN import GEN


def Exec(INPUT_NET,IE_OUTPUT,READCOLUMN,METRIC):
    # _IEDF=读取csv文件
    _IEDF = pd.read_csv(IE_OUTPUT)
    gen = GEN(_NetPath=INPUT_NET, _IEDF=_IEDF, METRIC=METRIC, READCOLUMN=READCOLUMN)
    gen._Calculate_GEN().to_csv(GEN_OUTPUT, index=False)


if __name__ == "__main__":
    # INPUT_NET=.net文件
    # IE_OUTPUT=IE的csv文件
    # METRIC=读取的csv文件中的指标列名字
    # READCOLUMN=读取classname列的名字
    # GEN_OUTPUT=输出文件的名字

    data_dir_path = "./data_IE/SORA/"
    data_dirs = os.listdir(data_dir_path)

    GEN_OUTPUT = ''
    for software_dir in data_dirs:
        print(software_dir)
        software_path = data_dir_path + software_dir + "/"
        file_list = os.listdir(software_path)
        INPUT_NET = None
        for file_name in file_list:
            if file_name.endswith('.net'):
                INPUT_NET = os.path.join(software_path, file_name)
                break
        if INPUT_NET is None:
            print("Error: No .net file found in the directory.")
            continue
        else:
            print("Network file path:", INPUT_NET)

            IE_OUTPUT = software_path + software_dir + ".csv"
            GEN_OUTPUT = INPUT_NET.replace('.net', '_IE_GEN.csv')
            METRIC = 'IERank'
            READCOLUMN = ['ClassName']
            print(IE_OUTPUT)
            Exec(INPUT_NET, IE_OUTPUT, READCOLUMN, METRIC)
            print('------------------------------\n------------------------------')
